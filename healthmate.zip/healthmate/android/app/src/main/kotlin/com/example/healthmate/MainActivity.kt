package com.example.healthmate

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
